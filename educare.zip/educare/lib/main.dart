import 'package:educare/screens/app_home.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EduCare',
      theme: ThemeData(
        primaryColor: Colors.blue[900],
        accentColor: Colors.blue[100],

      ),
      home: AppHome(),
    );
  }
}