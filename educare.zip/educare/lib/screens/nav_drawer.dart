import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var scrsz =MediaQuery.of(context).size;
    return Drawer(
    elevation: 5.0,
    child: Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue[200],Colors.blue[100]]
        )
      ),
      //color: Theme.of(context).accentColor,
      child: ListView(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.blue[900],Colors.blue[700]]
               )
            ),
            height: scrsz.height/4.5,
            //color: Theme.of(context).primaryColor,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  CircleAvatar(
                    backgroundColor: Theme.of(context).accentColor,
                    radius: 32.0,
                    child: Icon(Icons.person,color:Colors.white,size:35.0),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text("Rishabh Mehta",style: TextStyle(color: Colors.white,fontSize: 16.0),),
                  ),
                  Text("rishabhmehta1326@gmail.com",style: TextStyle(color: Colors.white,fontSize: 13.0),)
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 10.0),
            child: ListTile(leading: Icon(Icons.person_outline,color: Colors.white,),title: Text("My Accout",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 10.0),
            child: ListTile(leading: Icon(Icons.event_note,color: Colors.white,),title: Text("Events",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 10.0,),
            child: ListTile(leading: Icon(Icons.alarm_on,color: Colors.white,),title: Text("Reminders",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 10.0),
            child: ListTile(leading: Icon(Icons.settings,color: Colors.white,),title: Text("Settings",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 5.0),
            child: ListTile(leading: Icon(Icons.help,color: Colors.white,),title: Text("Help and Feedback",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          Padding(
            padding: const EdgeInsets.only(left:7.0,top: 5.0),
            child: ListTile(leading: Icon(Icons.exit_to_app,color: Colors.white,),title: Text("Logout",style:TextStyle(color:Colors.white,fontSize: 18.0),),),
          ),
          
        ],
      ),
      
    ),
  );
  }
}