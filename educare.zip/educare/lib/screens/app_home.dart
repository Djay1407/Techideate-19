import 'package:educare/screens/nav_drawer.dart';
import 'package:flutter/material.dart';

class AppHome extends StatefulWidget {
  @override
  _AppHomeState createState() => _AppHomeState();
}

class _AppHomeState extends State<AppHome> {
  @override
  Widget build(BuildContext context) {
    var scrsz =MediaQuery.of(context).size;
    return Scaffold(
      drawer: AppDrawer(),
      appBar: AppBar(
        title: Text("EduCare"),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search),
            onPressed: (){},
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size(scrsz.width, 50.0),
          child: Expanded(
                      child: ListView(
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  FlatButton(
                    child: Text("Home",style: TextStyle(color: Colors.white,fontSize: 17.0),),
                  ),
                   FlatButton(
                    child: Text("School",style: TextStyle(color: Colors.white,fontSize: 17.0),),
                  ),
                   FlatButton(
                    child: Text("College",style: TextStyle(color: Colors.white,fontSize: 17.0),),
                  ),
                   FlatButton(
                    child: Text("Start-ups",style: TextStyle(color: Colors.white,fontSize: 17.0),),
                  ),
                   FlatButton(
                    child: Text("institutes",style: TextStyle(color: Colors.white,fontSize: 17.0),),
                  ),
                  
                ],
              ),
          ),
          ),
      ),
    );
  }
}